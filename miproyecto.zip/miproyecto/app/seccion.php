<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class seccion extends Model
{
  
   protected $fillable = [
        'nombre_secion', 
        'codigo'
        
              ];
}

