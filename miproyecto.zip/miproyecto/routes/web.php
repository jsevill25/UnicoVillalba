<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EstudianteController;
use App\Http\Controllers\SeccionController;
use App\Http\Controllers\PagosController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/', function () {
    return view('welcome');
});



Route::get('/registroEstudi', function () {
    return view('admin.registroStudiante');

});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
// Route::resource('students', 'StudentRecordController');

Route::resource('/estudiantes', 'EstudianteController');

Route::resource('/secciones', 'SeccionController');

Route::resource('/pagos', 'PagosController');


