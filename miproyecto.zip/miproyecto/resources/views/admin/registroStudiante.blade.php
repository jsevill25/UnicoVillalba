 

@extends('layouts.admin')

@section('content')


 <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="row">
        <div class="col-md-12">
      <div class="box">
<div class="box-header with-border">
  <h1 class="box-title">Estudiantes <button class="btn btn-success" onclick="mostrarform(true)" id="btnagregar"><i class="fa fa-plus-circle"></i>Agregar</button></h1>
  <div class="box-tools pull-right">
<h1 class="box-title">secciones <button class="btn btn-success" onclick="mostrarformS(true)" id="btnagregar"><i class="fa fa-plus-circle"></i>Agregar</button></h1>
  <!--   <button class="btn btn-success" onclick="mostrarform(true)" id="btnagregar"><i class="fa fa-plus-circle"></i>Agregar</button> -->
  </div>
</div>
<!--box-header-->



<!--centro-->
<div class="panel-body table-responsive" id="listadoregistros">
  <table id="tbllistado" class="table table-striped table-bordered table-condensed table-hover">
    <thead>
      <th>nombre</th>
      <th>apellido</th>
      <th>fechaNC</th>
      <th>genero</th>
     
    </thead>
    <tbody>
    </tbody>
    <tfoot>
       <th>nombre</th>
      <th>apellido</th>
      <th>fechaNC</th>
      <th>genero</th>
     
    </tfoot>   
  </table>
</div>



<!-- formulario de estudiantes -->

<div class="panel-body" id="formularioregistros">
  <form action="" name="formulario" id="formulario" method="POST">
     @csrf

   <div class="form-group col-lg-6 col-md-6 col-xs-12">
      <label for="">Nombre(*):</label>
     
      <input class="form-control" type="text" name="nombre" id="nombre" maxlength="100" placeholder="Nombre" required>
    </div>
    <div class="form-group col-lg-6 col-md-6 col-xs-12">
      <label for="">Apellidos(*):</label>
      <input class="form-control" type="text" name="apellido" id="apellidos" maxlength="100" placeholder="Apellidos" required>
    </div>

    <div class="form-group col-lg-6 col-md-6 col-xs-12">
      <label for="">fech naciemento</label>
      <input class="form-control" type="text" name="fechaNC" id="fechaNC" maxlength="70" placeholder="Fecha">
    </div>

 <div class="form-group col-lg-6 col-md-6 col-xs-12">
      <label for="">Genero(*):</label>
     <select name="genero" id="iddepartamento" class="form-control select-picker" required>
      <option value="masculino">masculino
      </option>
       <option value="femenina">femenino
      </option>
     </select>
    </div>
    
    
    <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <button class="btn btn-primary" type="submit" id="btnGuardar"><i class="fa fa-save"></i>  Guardar</button>
      <button class="btn btn-danger" onclick="cancelarform()" type="button"><i class="fa fa-arrow-circle-left"></i> Cancelar</button>
    </div>
  </form>
</div>


<!-- registro de seccio -->
<div class="panel-body" id="idideseccion">

  <form action="" name="formulario" id="seccioformulario" method="POST">
     @csrf

   <div class="form-group col-lg-6 col-md-6 col-xs-12">
      <label for="">Nombre(*):</label>
     
      <input class="form-control" type="text" name="nombre" id="nombre" maxlength="100" placeholder="Nombre" required>
    </div>
    <div class="form-group col-lg-6 col-md-6 col-xs-12">
      <label for="">codig o(*):</label>
      <input class="form-control" type="text" name="codigo" id="apellidos" maxlength="100" placeholder="codigo" required>
    </div>

 
    
    
    <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <button class="btn btn-primary" type="submit" id="btnGuardar"><i class="fa fa-save"></i>  Guardar</button>
      <button class="btn btn-danger" onclick="cancelarformS()" type="button"><i class="fa fa-arrow-circle-left"></i> Cancelar</button>
    </div>
  </form>
</div>



<!-- fin de formularios -->








<!--modal para ver la venta-->
 <div class="modal fade" id="getCodeModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="width: 20% !important;">
     <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title">Cambio de contraseña</h4>
        </div>
        <div class="modal-body">
  <form action="" name="formularioc" id="formularioc" method="POST">
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Password:</label>
            <input class="form-control" type="hidden" name="idusuarioc" id="idusuarioc">
            <input class="form-control" type="password" name="clavec" id="clavec" maxlength="64" placeholder="Clave" required>
          </div>
          <button class="btn btn-primary" type="submit" id="btnGuardar_clave"><i class="fa fa-save"></i>  Guardar</button>
      <button class="btn btn-danger"  type="button"  data-dismiss="modal" ><i class="fa fa-arrow-circle-left"></i> Cancelar</button>
        </form>

        <div class="modal-footer">
          <button class="btn btn-default" type="button" data-dismiss="modal">Cerrar</button>
        </div>
</div>
</div>
</div>
<!--inicio de modal editar contraseña--->
<!--fin de modal editar contraseña--->
<!--fin centro-->
      </div>

      </div>
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->



  <!-- prueva tablaÇ -->
 



  </div>








  @endsection
  @section('scripts')


 <script >
   
var tabla;

//funcion que se ejecuta al inicio
function init(){
  mostrarformS(false);
   mostrarform(false);
   mostrarform_clave(false);
   listar();

$("#formularioc").on("submit",function(c){
    editar_clave(c);
   })
   $("#formulario").on("submit",function(e){
    guardaryeditar(e);
   })


   $("#imagenmuestra").hide();

//mostramos los permisos
$.post("../ajax/usuario.php?op=permisos&id=", function(r){
  $("#permisos").html(r);
});


   //cargamos los items al select departamento
   $.post("../ajax/departamento.php?op=selectDepartamento", function(r){
    $("#iddepartamento").html(r);
    $('#iddepartamento').selectpicker('refresh'); 
   });

   //cargamos los items al select tipousuario
   $.post("../ajax/tipousuario.php?op=selectTipousuario", function(r){
    $("#idtipousuario").html(r);
    $('#idtipousuario').selectpicker('refresh'); 
   });

}

//funcion limpiar
function limpiar(){
  $("#nombre").val("");
    $("#apellidos").val("");
  $("#direccion").val("");
  $("#iddepartamento").selectpicker('refresh');
  $("#idtipousuario").selectpicker('refresh');
  $("#email").val("");
  $("#login").val("");
  $("#clave").val("");
  $("#codigo_persona").val("");
  $("#imagenmuestra").attr("src","");
  $("#imagenactual").val("");
  $("#idusuario").val("");
}

//funcion mostrar formulario
function mostrarform(flag){
  limpiar();
  if(flag){
    $("#listadoregistros").hide();
    $("#formularioregistros").show();
    $("#btnGuardar").prop("disabled",false);
    $("#btnagregar").hide();
  }else{
    $("#listadoregistros").show();
    $("#formularioregistros").hide();
    $("#btnagregar").show();
  }
}

function mostrarformS(flag){
  limpiar();
  if(flag){
    $("#listadoregistros").hide();
    $("#idideseccion").show();
    $("#btnGuardar").prop("disabled",false);
    $("#btnagregar").hide();
  }else{
    $("#listadoregistros").show();
    $("#idideseccion").hide();
    $("#btnagregar").show();
  }
}


function mostrarform_clave(flag){
  limpiar();
  if(flag){
    $("#listadoregistros").hide();
    $("#formulario_clave").show();
    $("#btnGuardar_clave").prop("disabled",false);
    $("#btnagregar").hide();
  }else{
    $("#listadoregistros").show();
    $("#formulario_clave").hide();
    $("#btnagregar").show();
  }
}
//cancelar form
function cancelarform(){
  $("#claves").show();
  limpiar();
  mostrarform(false);
}
function cancelarform_clave(){
  limpiar();
  mostrarform_clave(false);

}

function cancelarformS(){
  $("#claves").show();
  limpiar();
  mostrarformS(false);
}





//funcion listar
function listar(){
  tabla=$('#tbllistado').dataTable({
    "aProcessing": true,//activamos el procedimiento del datatable
    "aServerSide": true,//paginacion y filrado realizados por el server
    dom: 'Bfrtip',//definimos los elementos del control de la tabla
    buttons: [
                  'copyHtml5',
                  'excelHtml5',
                  'csvHtml5',
                  'pdf'
    ],
    "ajax":
    {
      url:"{{url('/estudiantes')}}",
      type: "get",
      dataType : "json",
      error:function(e){
        console.log(e.responseText);
      }
    },
    "bDestroy":true,
    "iDisplayLength":10,//paginacion
    "order":[[0,"desc"]]//ordenar (columna, orden)
  }).DataTable();
}



//funcion para guardaryeditar activa
function guardaryeditar(e){
     e.preventDefault();//no se activara la accion predeterminada 
     $("#btnGuardar").prop("disabled",true);
     var formData=new FormData($("#formulario")[0]);

     $.ajax({
      url: "{{url('/estudiantes')}}",
      type: "POST",
      data: formData,
      contentType: false,
      processData: false,

      success: function(datos){
        bootbox.alert(datos);
        mostrarform(false);
        tabla.ajax.reload();
      }
     });
$("#claves").show();
     limpiar();
}







function editar_clave(c){
     c.preventDefault();//no se activara la accion predeterminada 
     $("#btnGuardar_clave").prop("disabled",true);
     var formData=new FormData($("#formularioc")[0]);

     $.ajax({
      url: "../ajax/usuario.php?op=editar_clave",
      type: "POST",
      data: formData,
      contentType: false,
      processData: false,

      success: function(datos){
        bootbox.alert(datos);
        mostrarform_clave(false);
        tabla.ajax.reload();
      }
     });

     limpiar();
   $("#getCodeModal").modal('hide');
}



function mostrar(idusuario){
  $.post("../ajax/usuario.php?op=mostrar",{idusuario : idusuario},
    function(data,status)
    {
      data=JSON.parse(data);
      mostrarform(true);

      if ($("#idusuario").val(data.idusuario).length==0) {
            $("#claves").show();
            
           }else{
      $("#claves").hide();
      }

           $("#nombre").val(data.nombre);
            $("#iddepartamento").val(data.iddepartamento);
            $("#iddepartamento").selectpicker('refresh');
            $("#idtipousuario").val(data.idtipousuario);
            $("#idtipousuario").selectpicker('refresh');
            $("#apellidos").val(data.apellidos);
            $("#email").val(data.email);
            $("#login").val(data.login);
            $("#codigo_persona").val(data.codigo_persona);
            $("#imagenmuestra").show();
            $("#imagenmuestra").attr("src","../files/usuarios/"+data.imagen);
            $("#imagenactual").val(data.imagen);
            $("#idusuario").val(data.idusuario);

 
    });



  $.post("../ajax/usuario.php?op=permisos&id="+idusuario, function(r){
  $("#permisos").html(r);
});
}



function mostrar_clave(idusuario){
   $("#getCodeModal").modal('show');
  $.post("../ajax/usuario.php?op=mostrar_clave",{idusuario : idusuario},
    function(data,status)
    {
      data=JSON.parse(data);
            $("#idusuarioc").val(data.idusuario);
    });
}

//funcion para desactivar
function desactivar(idusuario){
  bootbox.confirm("¿Esta seguro de desactivar este dato?", function(result){
    if (result) {
      $.post("../ajax/usuario.php?op=desactivar", {idusuario : idusuario}, function(e){
        bootbox.alert(e);
        tabla.ajax.reload();
      });
    }
  })
}

function activar(idusuario){
  bootbox.confirm("¿Esta seguro de activar este dato?" , function(result){
    if (result) {
      $.post("../ajax/usuario.php?op=activar", {idusuario : idusuario}, function(e){
        bootbox.alert(e);
        tabla.ajax.reload();
      });
    }
  })
}

function generar(longitud)
{
  long=parseInt(longitud);
  var caracteres = "abcdefghijkmnpqrtuvwxyzABCDEFGHIJKLMNPQRTUVWXYZ2346789";
  var contraseña = "";
  for (i=0; i<long; i++) contraseña += caracteres.charAt(Math.floor(Math.random()*caracteres.length));
    $("#codigo_persona").val(contraseña);
}

init();




// function loadDataTable(
//   username ='',date_of_reg='',
//   last_login = '',group_name=''
//  ) {
//   console.log("herer");
//   var dataTable = $('#active_user').dataTable({
//   processing: true,
//   serverSide: true,
//   ajax: {
//       url: '',
//       type: 'post',
//       data: {  username : username,date_of_reg:date_of_reg,
//                 last_login:last_login,group_name:group_name}
//     },
//    columns: [
//     {data: 'username', name: 'username'},
//     {data: 'date_of_reg', name: 'date_of_reg'},
//     {data: 'last_login', name: 'last_login'},
//     {data: 'group_name', name: 'group_name'},
//     ],
//    dom: 'lBfrtip',
//       buttons: {
//         buttons: [
//           { extend: 'copy', className: 'copyButton', 
//               exportOptions: {columns: [ 0, 1, 2,3] }},

//           { extend: 'csv', className: 'csvButton', 
//              exportOptions: {columns: [ 0, 1, 2,3] }},

//           { extend: 'excel', className: 'excelButton', 
//              exportOptions: {columns: [ 0, 1, 2,3] }},
//           { extend: 'pdf', className: 'pdfButton', 
//             exportOptions: {columns: [ 0, 1, 2,3] }},
//           { extend: 'print', className: 'printButton',
//               exportOptions: {columns: [ 0, 1, 2,3] }}
//           ]
//         }
//      });

//    Backend.DataTable.init(dataTable);  
//  }

//     $('#table_id').DataTable( {

//   });
 </script>

  @endsection